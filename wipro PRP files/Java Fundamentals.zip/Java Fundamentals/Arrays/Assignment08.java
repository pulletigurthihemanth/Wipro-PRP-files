//Employee id: 20450468
/* Write a program to print the element of an array that has occurred the highest number of times
Eg) Array -> 10,20,10,30,40,100,99
O/P:10*/
public class Assignment08{
	public static int mostFrequent(int[] arr, int n)
  {
    int maxcount = 0;
    int element_having_max_freq = 0;
    for (int i = 0; i < n; i++) {
      int count = 0;
      for (int j = 0; j < n; j++) {
        if (arr[i] == arr[j]) {
          count++;
        }
      }
  
      if (count > maxcount) {
        maxcount = count;
        element_having_max_freq = arr[i];
      }
    }
  
    return element_having_max_freq;
  }
  
  
  public static void main(String[] args)
  {
    int[] arr = { 10,20,10,30,40,100,99 };
    int n = arr.length;
    System.out.print(mostFrequent(arr, n));
  }

	}
