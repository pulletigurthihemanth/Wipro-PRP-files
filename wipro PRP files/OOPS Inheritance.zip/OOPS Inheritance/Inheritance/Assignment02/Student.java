//Employee id: 20450468
/*A HighSchool application has two classes: the Person superclass and the Student subclass. 
Using inheritance, in this lab you will create two new classes, Teacher and CollegeStudent.
A Teacher will be like Person but will have additional properties such as salary
(the amount the teacher earns) and subject (e.g. “Computer Science”, “Chemistry”, “English”, “Other”). 
The CollegeStudent class will extend the Student class by adding a year (current level in college) and
 major (e.g. “Electrical Engineering”, “Communications”, “Undeclared”).*/
public class Student{
	private String myName ; 
	private int myAge;
	private String myGender;
	public Student(String name, int age, String gender){
		myName = name;
	    myAge = age;
	    myGender = gender;
 }
	public String getName(){
		return myName;
	 }
	public int getAge(){
		return myAge;
}
	public String getGender(){
		return myGender;
}
	public void setName(String name){
		myName = name;
}
	public void setAge(int age){
		myAge = age;
}
	public void setGender(String gender){
		myGender = gender;
}
	public String toString(){
		return myName + ", age: " + myAge + ", gender: " +myGender;
}
}
public class student extends person {
	private String myIdNum; 
private double myGPA;
public student(String name, int age, String gender,String idNum, double gpa){
	super(name, age, gender);
	myIdNum = idNum;
	myGPA = gpa;
}
public String getIdNum(){
	return myIdNum;
}
public double getGPA(){
	return myGPA;
 }
public void setIdNum(String idNum){
	myIdNum = idNum;
}
public void setGPA(double gpa){
	myGPA = gpa;
}
public String toString(){
	return super.toString() + ", student id: " + myIdNum + ", gpa: " + myGPA;
}
}
