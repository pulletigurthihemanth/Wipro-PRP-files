package Displaythetittle;

import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment02
{

	public static void main(String[] args)
	{
		ChromeDriver driver = new ChromeDriver();
		EdgeDriver driver = new EdgeDriver();     // running at edge browser
		driver.get("https://demo.guru99.com/test/newtours/login.php");
	}

}
