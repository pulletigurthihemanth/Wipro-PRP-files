package Displaythetittle;

import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment01 
{

	public static void main(String[] args) 
	{
		ChromeDriver driver=new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.get("https://demo.opencart.com/");
		   String tittle=driver.getTitle();
		   String url=driver.getCurrentUrl();
		   System.out.println(tittle);
		   System.out.println(url);

	}

}
