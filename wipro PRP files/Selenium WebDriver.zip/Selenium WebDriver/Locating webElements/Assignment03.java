//Emp id; 20450468
//Choose the Unique locating elements for different types of Buttons(Double Click , Right Click Me, Click Me) from the link
//https://demoqa.com/buttonspackage Web;
package Web;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Assignment03 
{

	public static void main(String[] args) 
	{
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/buttons");
		Actions act=new Actions(driver);
		WebElement dou=driver.findElement(By.xpath("(//button[@id=\"doubleClickBtn\"])[1]"));
		act.doubleClick(dou).perform();
		Actions action=new Actions(driver);
		WebElement val = driver.findElement(((By.xpath("(//button[@class='btn btn-primary'])[2]"))));
		act.contextClick(val).perform();
		driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[3]")).click();
		

	}

}
