package Web;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Assignment06
{

	public static void main(String[] args) 
	{
		 ChromeDriver driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);	  
		  driver.get("http://www.Ebay.com");
		  driver.findElement(By.xpath("//input[@id=\"gh-ac\"]")).sendKeys("Apple");
		  driver.findElement(By.id("gh-btn")).click();
		  driver.findElement(By.id("gh-cat")).click();
		  Select se=new Select(driver.findElement(By.id("gh-cat")));
		  se.selectByValue("11233");
		  driver.findElement(By.id("gh-btn")).click();
		  List<WebElement> lst=driver.findElementsByClassName("srp-river-results");
		  for(int i=0;i<lst.size();i++) 
		  {
			  System.out.println(lst.get(i).getText());
			  }
		  System.out.println(lst.get(10).getText());
		  }
}
