package Web;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assigtnment05 
{

	public static void main(String[] args) 
	{
		 ChromeDriver driver=new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);	  
		  driver.get("http://www.flipkart.com");
		  List<WebElement> links= driver.findElements(By.xpath("//a"));
		  System.out.println("Total links in the home page :"+links.size());
		  
		  for(WebElement link : links)
		  {
			  System.out.println(link.getAttribute("href"));
		  }
		  

	}

}
