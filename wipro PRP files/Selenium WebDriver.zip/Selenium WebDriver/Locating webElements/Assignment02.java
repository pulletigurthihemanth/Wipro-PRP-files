package Web;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment02 
{

	public static void main(String[] args) 
	{
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.opencart.com/");
		driver.findElement(By.xpath("//span[text()='My Account']")).click();
		driver.findElement(By.xpath("//a[text()='Register']")).click();
		driver.findElement(By.xpath("//input[@id='input-firstname']")).sendKeys("Hemanth");
		driver.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Pulletigurthi");
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys("pulletigurthihemanth@gmail.com");
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys("Qwerfv!234");
		
		
		
		

	}

}
